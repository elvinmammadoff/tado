## HTML Documentation Template

An HTML documentation template for Envato authors. This template can be used to document Envato Market template, themes and plugins.

![Documentation Preview](http://miloslider.netlify.app/documentation/)

Although, this template is pretty basic and minimal in nature. Here are few of it's salient features:

## Key Features

- Foundation Base Framework
- Custom Google Fonts
- Sticky Sidebar support
- Favicon supported
- Syntax Highlighter supported
- Smooth Scroll support

